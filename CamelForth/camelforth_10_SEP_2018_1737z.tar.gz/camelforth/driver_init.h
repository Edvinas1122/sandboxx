#ifndef DRIVER_INIT_INCLUDED
#define DRIVER_INIT_INCLUDED

// #include "atmel_start_pins.h"

#ifdef __cplusplus
extern "C" {
#endif
// void system_init(void);
#ifdef __cplusplus
}
#endif
#endif // DRIVER_INIT_INCLUDED
