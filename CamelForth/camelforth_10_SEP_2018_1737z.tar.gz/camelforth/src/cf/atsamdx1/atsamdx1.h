#include <string.h>

#define timeStamp(t,l) \
    "Mon Sep 10 17:30:43 UTC 2018\n\n", 32
// current target branch:
#define branchStamp(b,l) \
    "On branch continue_forked-f-GP_     ", 36

//  "On branch continue_forked-d-GOOD_PROGRESS_    ", 46
//   12345678901234567890123456789012345678901234567890
// #define branchStamp(b,l) "master                   ", 25

#define stack_buffer_length 64

extern unsigned int *psp;
extern void itoa_write(void);
extern int input_integer;
extern void cmf_itoa(int n, char s[]);
extern char print_string[stack_buffer_length];
char print_string[stack_buffer_length];
extern struct io_descriptor *io;
extern void bold_italics_white(void);
extern void italics(void);
extern void bold_italics(void);
extern void n1uro_italics(void);
extern void fg_white_force_bold(void);
extern void fg_white(void);
extern void fg_yellow(void);
extern void bg_black(void);
extern void bg_blue(void);
extern void bg_red(void);
extern void color_reset(void);
extern void color_bold(void); // experimental
extern void _que(void);
extern void _ok(void);
extern void _bkbar(void); // broken bar
extern void _spc(void);
extern void _cr(void); // line 113
extern void cr(void);
extern void USART_0_example_upper_camelforth(void);
extern void USART_0_example_lower_camelforth(void);
