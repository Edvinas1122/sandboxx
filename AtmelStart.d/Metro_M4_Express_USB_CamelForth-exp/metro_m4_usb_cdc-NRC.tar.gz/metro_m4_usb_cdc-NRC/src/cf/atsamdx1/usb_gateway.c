/* wa1tnr - September, 2018 LGPL v2.1 */

#include <atmel_start.h>
#include "atsamdx1_getkey_usb.inc"
