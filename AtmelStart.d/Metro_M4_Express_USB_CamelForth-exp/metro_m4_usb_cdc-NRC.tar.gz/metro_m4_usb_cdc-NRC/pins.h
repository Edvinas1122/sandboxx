#define PORTA 0
#define PORTB 1
extern void pins_setup();
extern void toggle_d13(void);
extern void reset_d13(void);
