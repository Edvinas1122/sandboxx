#!/bin/sh
arm-none-eabi-objdump -S -z -I /path/to/top/of/source /path/to/this.elf
