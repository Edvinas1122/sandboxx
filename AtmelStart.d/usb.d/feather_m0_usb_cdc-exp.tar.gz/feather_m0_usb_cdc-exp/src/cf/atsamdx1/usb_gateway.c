/* wa1tnr - September, 2018 LGPL v2.1 */

#include <atmel_start.h>
// #include "atsamdx1_getkey.inc"
#include "atsamdx1_getkey_usb.inc"

/*
extern void camelforth(void);
*/
// struct io_descriptor *io; // crutch

/*
void USART_0_setup_local(void) {
    usart_sync_get_io_descriptor(&USART_0, &io);
    usart_sync_enable(&USART_0);
}
*/

// USB_loop_camelforth();

// extern char usbd_cdc_buffer[CDCD_ECHO_BUF_SIZCF / 4];

/*
void USB_loop_camelforth(void) {
    int count = 1; // KLUDGE wa1tnr
// void USART_0_loop_camelforth(void) {
    while(-1) {
        // io_write(io, (uint8_t *)"usart_gateway.c   ", 18);
        // tib_buffer[0]='X';
        // usbd_cdc_buffer[0]='V';
        // usbd_cdc_buffer[1]='\0';
        // cdcdf_acm_write((uint8_t *)usbd_cdc_buffer, count);
        // camelforth();
    }
}
*/
